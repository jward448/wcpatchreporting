#Written by James Ward, Late May 2017 as part of "WannaCry PatchChecker and Reporting" system


$date = Get-Date

$a = "<style>"
$a = $a + "BODY{background-color:MediumAquamarine;}"
$a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$a = $a + "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;}"
$a = $a + "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;}"
$a = $a + "</style>"

$m = "<h1 style=`"color: #5e9ca0;`">WannaCry Patched Windows Computer Status</h1>"
# example: $m = $m + "<h2 style=`"color: #2e6c80;`">Scans&nbsp;are done at least once a day from MYSERVER</h2>"  
$m = $m + "<h2 style=`"color: #2e6c80;`">Scans&nbsp;are done at least once a day from {replace with short name for script host}</h2>"

$m = $m + "<h3 style=`"color: #FF0000;`">Scan currently in progress... Started at: $date</h3>"
$m = $m + "<h3 style=`"color: #BB33FF;`">Check this page at least 4 hours after scan start time for latest results</h3>"

# example: $m = $m + "<p><strong><a href=`"http://myserver.mydomain.local/reports/archive`">Archived Reports</a></strong></p>"
$m = $m + "<p><strong><a href=`"http://{replace with script host here}/reports/archive`">Archived Reports</a></strong></p>"


ConvertTo-Html -head $m | Out-File c:\inetpub\reports\main.html

