#Written by James Ward, Late May 2017 as part of "WannaCry PatchChecker and Reporting" system


$noconnects = @()
$patched = @()
$unpatched = @()
$unparray = @()
$tarray = @()
$trouble = @()
$date = Get-Date

$reader = [System.IO.File]::OpenText("c:\scripts\logs\wc.log")
while($null -ne ($line = $reader.ReadLine())) {
    if ($line -like '*Unable to gather hotfix information*') {$trouble += ($line -replace '\*\*\*' -replace 'Unable to gather hotfix information').Trim()}
    if ($line -like '*Unable to connect*') {$noconnects += ($line -replace '\*\*\*\*' -replace 'Unable to connect.').Trim() + ",NOCONNECT"}
    if ($line -like '*is patched with*') {$patched += ($line -replace ' is patched with ',',').Trim()}
    if ($line -like '*UNPATCHED!*') {$unpatched += ($line -replace '\*\*\*\*\*' -replace 'IS UNPATCHED!').Trim()}
}


$a = "<style>"
$a = $a + "BODY{background-color:MediumAquamarine;}"
$a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$a = $a + "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;}"
$a = $a + "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;}"
$a = $a + "</style>"

$m = "<h1 style=`"color: #5e9ca0;`">WannaCry Patched Windows Computer Status</h1>"
$m = $m + "<h2 style=`"color: #2e6c80;`">Scans&nbsp;are done at least once a day from {replace with short name of script host here}</h2>"
$m = $m + "<h3 style=`"color: #BB33FF;`">Last Updated: $date</h3>"
$m = $m + "<p>See the latest results below:</p>"
$m = $m + "<ul>"
$m = $m + "<li><a href=`"http://{replace with FQDN of script host here}/reports/unpatched.html`">Unpatched&nbsp;Computer List</a></li>"
$m = $m + "<li><a href=`"http://{replace with FQDN of script host here}/reports/badhotfixinfo.html`">Computers that did not respond properly to patch scan</a></li>"
$m = $m + "</ul>"
$m = $m + "<table style=`"width:30%`">"
$m = $m + "<tr>"
$m = $m + "<th align=`"left`">Computers</th>"
$m = $m + "<th align=`"left`">Result</th>" 
$m = $m + "</tr>"
$m = $m + "<tr><td align=`"middle`">" + $trouble.count + "</td><td>computers that were unable to report hotifix information</td></tr>"
$m = $m + "<tr><td align=`"middle`">" + $patched.count + "</td><td>computers that are patched</td></tr>"
$m = $m + "<tr><td bgcolor=`"red`" align=`"middle`">" + $unpatched.count + "</td><td>computers that are unpatched and at risk</td></tr>"
$m = $m + "<tr><td align=`"middle`">" + $noconnects.count + "</td><td>computers that were unreachable</td></tr>"
$m = $m + "</table>"
$m = $m + "<p><strong><a href=`"http://{replace with script host here}/reports/archive`">Archived Reports</a></strong></p>"

$m = $m + "<table style=`"width:30%`">"
$m = $m + "<tr>"
$m = $m + "<th align=`"left`">Current KB Check List</th>"
$m = $m + "</tr>"
$m = $m + "<tr><td align=`"left`"> KB3205409 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB3210720 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB3210721 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB3212646 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB3213986 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012212 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012213 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012214 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012215 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012216 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012217 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012218 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012220 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012598 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4012606 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4013198 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4013389 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4013429 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015217 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015438 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015546 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015547 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015548 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015549 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015550 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015551 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015552 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015553 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4015554 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4016635 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4019213 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4019214 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4019215 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4019216 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4019263 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4019264 </td></tr>"
$m = $m + "<tr><td align=`"left`"> KB4019472 </td></tr>"
$m = $m + "</table>"


Foreach ($line in $unpatched)
{ 
$result = $line.split("{,}")
$obj = new-object psobject -Property @{
                   ComputerName = $result[0]
		   OS = $result[1]
               }
$unparray += $obj
}
$unparray | Format-Table ComputerName,OS
$unparray| ConvertTo-Html -head $a -body "<H2>Not Yet WannaCry Patched</H2> <H3>Last Updated: $date</H3>" | Out-File c:\inetpub\reports\unpatched.html


Foreach ($line in $trouble)
{
$result = $line.split("{,}")
$obj = new-object psobject -Property @{
                   ComputerName = $result[0]
		   OS = $result[1]
               }
$tarray += $obj
}
$tarray | Format-Table ComputerName,OS
$tarray| ConvertTo-Html -head $a -body "<H2>Trouble Getting Hotfix Info</H2> <H3>Last Updated: $date</H3>"| Out-File c:\inetpub\reports\badhotfixinfo.html

ConvertTo-Html -head $m | Out-File c:\inetpub\reports\main.html

